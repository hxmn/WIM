cHANGE TO THE DDL OCTOBER 26, 2006 - 	1.  All file names are now upper case  
					2.  )); error in the foreign key file has been resolved 



 PPDM Version 3.71 DDL, Oracle Format

 Generated for Oracle on May 31, 2005
 
 USER agrees on receipt of the PPDM model and supporting material that 
 its use by USER constitutes acceptance by the USER that: 
 
 1.  The PPDM model and supporting material are provided "as is" 
     without any warranty of any kind, either statutory, express 
     or implied, including, without limiting the foregoing, implied 
     warranties of merchantability of fitness for a particular 
     purpose, or warranty as to non-infringement with existing or 
     future copyright, patent of other intellectual property rights 
     claimed or asserted by any third party; 

 2.  PPDM shall not be liable to User nor to anyone else who uses or 
     otherwise obtains the PPDM model and supporting material, 
     either directly or indirectly from User, for direct, indirect, 
     special or consequential damages or other loss of cost however arising; 

 3.  User agrees to indemnify and hold PPDM harmless from any third party 
     claims arising directly or indirectly, or however arising, from the 
     PPDM model and supporting material provided to the User; 

 4.  The user acknowledges that the data model and all its supporting 
     material is under copyright notice and that all rights are reserved 
     by PPDM, the Public Petroleum Data Model Association. 




CAUTION :  THIS DDL CONTAINS ADDITIONAL CODE TO CREATE BITMAP INDEXES
	   FOR THE REFERENCE TABLES. YOU CAN CHOOSE TO RUN THE REGULAR 
           INDEXES FOR THESE REFERENCE TABLES BY UNCOMMENTING THE FOLLOWING
           LINES :
		-- @@PPDM371_REG.INDX
		-- @@PPDM371.RQUAL_INDX
	   THEN COMMENTING THE FOLLOWING BITMAP INDEX LINES 
		@@PPDM371_BITMAP.INDX
		@@PPDM371_BITMAP.RQUAL_INDX
	   FROM THE MASTER PPDM371.SQL FILE
	   
	   IF YOU FAIL TO ADJUST THESE LINES APPROPRIATELY THE RESULT WILL
	   BE ERRORS AND POSSIBLELY INCORRECT INDEXES FOR YOUR APPLICATION